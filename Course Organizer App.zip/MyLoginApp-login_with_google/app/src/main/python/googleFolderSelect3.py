from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from oauth2client.service_account import ServiceAccountCredentials
import requests

#Authorize the API
scope = ['https://www.googleapis.com/auth/drive','https://www.googleapis.com/auth/drive.file']
file_name = 'client_service.json'
creds = ServiceAccountCredentials.from_json_keyfile_name(file_name,scope)

# Replace with the path to your credentials JSON file
# creds = Credentials.from_authorized_user_file('path/to/credentials.json')

# Replace with the URL of the file you want to download
url = 'https://docs.google.com/document/d/1eZ83ZhAYKr2Gp_9UlNriorIOu8QBWFyC/edit?usp=sharing&ouid=101747573944982626859&rtpof=true&sd=true'
file_id = url.split('/')[-2]

service = build('drive', 'v3', credentials=creds)

try:
    file = service.files().get(fileId=file_id).execute()
    download_url = file.get('exportLinks')['application/pdf']
    resp = requests.get(download_url, headers={'Authorization': 'Bearer ' + creds.token})
    file_name = file['name']
    file_metadata = {'name': file_name}
    drive_file = service.files().create(body=file_metadata, media_body=resp.content).execute()
    print(f"File '{file_name}' has been downloaded to your Google Drive.")
except HttpError as error:
    print(f'An error occurred: {error}')
